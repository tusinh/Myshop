<?php
require __DIR__ . '/vendor/autoload.php';
include('connect/connect.php');
$json = file_get_contents('php://input');
$obj = json_decode($json, true);
$name = $obj['name'];
$email = $obj['email'];
$address = $obj['address'];
$arrayDetail = $obj['arrayDetail'];
$jsonDetail =json_encode($arrayDetail);
if($name !='' && $email != '' && $address!=''){
  $tongtien = 0;
  foreach ($arrayDetail as $value) {
    $id_sp = $value['id'];
    $sl=$value['quantity'];
    $sanpham = $mysqli->query("select price from product where id=$id_sp");
    $product = mysqli_fetch_assoc($sanpham);
    $tongtien += $product['price']*$sl;
  }
  $todate = date('Y-m-d h:i:s');
  $sql = "INSERT INTO donhang(cart_detail,nameuser,email,address,total,date_order) VALUES ('$jsonDetail','$name', '$email','$address', $tongtien,'$todate')";
  $mysqli->query($sql);
  $id_bill = $mysqli->insert_id;
  foreach ($arrayDetail as $value) {
    $product = $mysqli->query("Select * FROM product where id=$value[id]");
    $product = mysqli_fetch_assoc($product);
    $price = $product['price'];
    $sql = "INSERT INTO donhang_chitet(id_donhang,id_product, quantity, price) VALUES ($id_bill, $value[id], $value[quantity], $price)";
    $mysqli->query($sql);

  }

  echo 'THEM_THANH_CONG';
}
else{
	echo 'Vui long dien day du thong tin';
}

?>
